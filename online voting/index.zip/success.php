<!-- success.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submission Successful</title>
    <link rel="stylesheet" href="./success.css"> 
</head>
<body>
    <div class="container">
        <h2>Thank You!</h2>
        <p>Your vote has been submitted successfully.</p>
        <a href="index.html" class="btn">Submit Another Vote</a>
    </div>
</body>
</html>
